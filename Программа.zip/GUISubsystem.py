﻿#GUISubsystem.py
import DatabaseSubsystem as DS
import GraphSubsystem as GS
import sys
from PyQt4 import QtCore, QtGui
from PyQt4.Qt import *
import numpy as NP
from numpy import sqrt
from matplotlib import rc
from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas 
#from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure
from matplotlib import pyplot as PLT

oDS = DS.TDatabaseSubsystem()

class TfrmRegistration(QDialog):
	def __init__(self):
		super(TfrmRegistration, self).__init__()
		self.setWindowTitle("Регистрация")
		self.lblLogin = QLabel('Имя пользователя:')
		self.lblPassword = QLabel('Пароль:')
		self.lblPassword2 = QLabel('Пароль (ещё раз):')
		self.edtLogin = QLineEdit()
		self.edtPassword = QLineEdit()
		self.edtPassword2 = QLineEdit()
		self.btnRegister = QPushButton('Регистрация...')
		
		self.loHLogin = QHBoxLayout()
		self.loHPassword = QHBoxLayout()
		self.loHPassword2 = QHBoxLayout()
		self.loVPrime = QVBoxLayout()
		
		self.edtInit()
		self.btnInit()
		self.loInit()
	def loInit(self):
		self.loHLogin.addWidget(self.lblLogin)
		self.loHLogin.addWidget(self.edtLogin)
		self.loHPassword.addWidget(self.lblPassword)
		self.loHPassword.addWidget(self.edtPassword)
		self.loHPassword2.addWidget(self.lblPassword2)
		self.loHPassword2.addWidget(self.edtPassword2)
		self.loVPrime.addLayout(self.loHLogin)
		self.loVPrime.addLayout(self.loHPassword)
		self.loVPrime.addLayout(self.loHPassword2)
		self.loVPrime.addWidget(self.btnRegister)
		self.setLayout(self.loVPrime)
	def edtInit(self):
		self.edtPassword.setEchoMode(QLineEdit.Password)
		self.edtPassword2.setEchoMode(QLineEdit.Password)
		self.edtLogin.textChanged.connect(self.OnEditChange)
		self.edtPassword.textChanged.connect(self.OnEditChange)
		self.edtPassword2.textChanged.connect(self.OnEditChange)
	def btnInit(self):
		self.btnRegister.setEnabled(False)
		self.btnRegister.clicked.connect(self.OnBtnRegisterClick)
	def OnEditChange(self):
		if self.edtLogin.text() and self.edtPassword.text() and self.edtPassword2.text():
			self.btnRegister.setEnabled(True)
		else:
			self.btnRegister.setEnabled(False)
	def OnBtnRegisterClick(self):
		if self.edtPassword.text() == self.edtPassword2.text():
			decRegisterCode = oDS.RegisterUser(self.edtLogin.text(), self.edtPassword.text())
			if (decRegisterCode == 0):
				QMessageBox.information(self, 'Информация.', 'Регистрация прошла успешно. Используйте ваше имя и пароль для авторизации.')
				self.close()
			elif (decRegisterCode == 1):
				QMessageBox.critical(self, 'Внимание!', 'Такое имя пользователя уже присутствует. Выберите другое имя пользователя.')
				self.edtLogin.clear()
		else:
			QMessageBox.critical(self, 'Внимание!', 'Пароль и его подтверждение не совпадают.')
			self.edtPassword.clear()
			self.edtPassword2.clear()

class TfrmAuthorization(QWidget):
	def __init__(self):
		super(TfrmAuthorization, self).__init__()
		oDS.Connect(self)
		self.resize(300, 100)
		self.setWindowTitle("Авторизация")
		
		self.lblLogin = QLabel('Имя пользователя:', self)
		self.lblPassword = QLabel('Пароль:', self)
		self.edtLogin = QLineEdit(self)
		self.edtPassword = QLineEdit(self)
		self.btnLogin = QPushButton('Войти', self)
		self.btnRegister = QPushButton('Регистрация...', self)
		
		self.loGAuthData = QGridLayout()
		self.loHButtons = QHBoxLayout()
		self.loVPrime = QVBoxLayout()
		
		self.edtInit()
		self.btnInit()
		self.loInit()
	def loInit(self):
		self.loGAuthData.addWidget(self.lblLogin, 0, 0, 1, 1)
		self.loGAuthData.addWidget(self.edtLogin, 0, 1, 1, 1)
		self.loGAuthData.addWidget(self.lblPassword, 1, 0, 1, 1)
		self.loGAuthData.addWidget(self.edtPassword, 1, 1, 1, 1)
		self.loHButtons.addWidget(self.btnLogin)
		self.loHButtons.addWidget(self.btnRegister)
		self.loVPrime.addLayout(self.loGAuthData)
		self.loVPrime.addLayout(self.loHButtons)
		self.setLayout(self.loVPrime)
	def edtInit(self):
		self.edtLogin.setPlaceholderText('Введите своё имя.')
		self.edtPassword.setPlaceholderText('Введите свой пароль.')
		self.edtPassword.setEchoMode(QLineEdit.Password)
		self.edtLogin.textChanged.connect(self.OnEditChange)
		self.edtPassword.textChanged.connect(self.OnEditChange)
	def btnInit(self):
		self.btnLogin.setEnabled(False)
		self.btnLogin.clicked.connect(self.OnBtnLoginClick)
		self.btnRegister.clicked.connect(self.OnBtnRegisterClick)
	def OnEditChange(self):
		if (self.edtLogin.text()) and (self.edtPassword.text()):
			self.btnLogin.setEnabled(True)
		else:
			self.btnLogin.setEnabled(False)
	def OnBtnLoginClick(self):
		decAuthCode = oDS.AuthorizeUser(self.edtLogin.text(), self.edtPassword.text())
		if (decAuthCode == 0):
			QMessageBox.information(self, "Информация.", "Добро пожаловать, {}".format(self.edtLogin.text()))
			self.frmMain = TfrmMain(self.edtLogin.text())
			self.close()
		elif (decAuthCode == 1):
			QMessageBox.critical(self, "Внимание!", "Имя пользователя и/или пароль неверны.")
			self.edtLogin.clear()
			self.edtPassword.clear()
			return
		elif (decAuthCode == 2):
			QMessageBox.critical(self, "Внимание!", "Такого имени пользователя нет в базе данных.")
			self.edtLogin.clear()
			self.edtPassword.clear()
			return
	def OnBtnRegisterClick(self):
		self.frmRegistration = TfrmRegistration()
		self.frmRegistration.exec_()

class TfrmMain(QMainWindow):
	def __init__(self, ALogin):
		super(TfrmMain, self).__init__()
		self.resize(800, 512)
		self.setWindowTitle("Метод ближайшего соседа")
		self.statusBar = QStatusBar()
		self.statusBar.showMessage("Вы вошли под именем: {}".format(ALogin), -1)
		self.setStatusBar(self.statusBar)
		self.actionsInit()
		self.menuInit()
		self.toolBarInit()
		self.wCentral = QWidget(self)
		self.setCentralWidget(self.wCentral)
		self.loHPrime = QHBoxLayout()
		self.loVLeft = QVBoxLayout()
		self.loVTop = QVBoxLayout()
		self.lblEnterVertices = QLabel("Введите количество вершин в графе:")
		self.edtVerticesCount = QLineEdit()
		self.lblEnterStart = QLabel("Введите номер стартового города:")
		self.edtStartNumber = QLineEdit()
		self.GraphEnvironmentInit()
		self.loInit()
		self.show()
	def actionsInit(self):
		self.actExit = QAction("Выход", self)
		self.actExit.setShortcut('Ctrl+Q')
		self.actExit.setStatusTip('Выход из системы.')
		self.connect(self.actExit, QtCore.SIGNAL('triggered()'), QtCore.SLOT('close()'))
		self.actSaveAs = QAction("Сохранить результат решения как...", self)
		self.actSaveAs.setShortcut('Ctrl+S')
		self.actSaveAs.setStatusTip('Сохранение графа с результатом решения задачи коммивояжёра в графический файл.')
		self.actSaveAs.triggered.connect(self.ActSaveAsExecute)
		self.actCallHelp = QAction("Справка...", self)
		self.actCallHelp.setShortcut('F1')
		self.actCallHelp.setStatusTip('Вызвать краткую справку.')
		self.actCallHelp.triggered.connect(self.ActCallHelp)
		self.actRandomGen = QAction("Сгенерировать граф в случайном порядке", self)
		self.actRandomGen.setShortcut('Ctrl+R')
		self.actRandomGen.setStatusTip('Сгенерировать граф в случайном порядке.')
		self.actRandomGen.triggered.connect(self.ActRandomGen)
		self.actSolve = QAction("Решить задачу коммивояжёра", self)
		self.actSolve.setShortcut('F3')
		self.actSolve.setStatusTip('Решить задачу коммивояжёра методом ближайшего соседа.')
		self.actSolve.triggered.connect(self.ActSolve)
	def menuInit(self):
		self.mmMain = self.menuBar()
		miGraph = self.mmMain.addMenu("&Граф")
		miGraph.addAction(self.actRandomGen)
		miGraph.addAction(self.actSolve)
		miGraph.addSeparator()
		miGraph.addAction(self.actSaveAs)
		miGraph.addSeparator()
		miGraph.addAction(self.actExit)
	def toolBarInit(self):
		self.tbMain = self.addToolBar('Основная панель')
		self.tbMain.addAction(self.actExit)
		self.tbMain.addSeparator()
		self.tbMain.addAction(self.actSolve)
		self.tbMain.addAction(self.actSaveAs)
		self.tbMain.addSeparator()
		self.tbMain.addAction(self.actCallHelp)
	def GraphEnvironmentInit(self):
		self.figure = Figure()
		self.canvas = FigureCanvas(self.figure)
		self.canvas.draw()
		self.memoData = QTextEdit()
	def loInit(self):
		self.loVTop.addWidget(self.lblEnterVertices)
		self.loVTop.addWidget(self.edtVerticesCount)
		self.loVTop.addWidget(self.lblEnterStart)
		self.loVTop.addWidget(self.edtStartNumber)
		self.loVLeft.addLayout(self.loVTop)
		self.loVLeft.addWidget(self.memoData)
		self.loHPrime.addLayout(self.loVLeft)
		self.loHPrime.addWidget(self.canvas)
		self.wCentral.setLayout(self.loHPrime)
	def ActSaveAsExecute(self):
		strFileName = QFileDialog.getSaveFileName(self, "Выберите место сохранения графа.", "C:/", "PNG (*.png);; All Files (*)")
		if (strFileName != ""):
			self.figure.savefig(strFileName)
	def ActRandomGen(self):
		self.canvas.figure.clear()
		self.oGS.RandomGenerate()
		self.oGS.NormalizeWeights()
		self.oGS.DrawGraph()
		self.canvas.draw()
	def ActSolve(self):
		try:
			self.canvas.figure.clear()
			self.memoData.clear()
			self.memoData.append("Внимание! Вершины ниже считаются с нуля.")
			self.memoData.append("Количество вершин в графе: {}".format(self.edtVerticesCount.text()))
			self.memoData.append("Стартовый город: {}".format(self.edtStartNumber.text()))
			if (int(self.edtVerticesCount.text()) <= int(self.edtStartNumber.text())):
				QMessageBox.critical(self, "Внимание!", "Номер стартового города должен быть меньше максимального номера города.")
				return
			if (int(self.edtStartNumber.text()) < 0):
				QMessageBox.critical(self, "Внимание!", "Номер стартового города должен быть больше нуля.")
				return
			if (int(self.edtVerticesCount.text()) <= 0):
				QMessageBox.critical(self, "Внимание!", "Количество вершин должно быть больше нуля.")
				return
			self.oGS = GS.TGraphSubsystem(int(self.edtVerticesCount.text()), int(self.edtStartNumber.text()), self.figure)
			self.oGS.RandomGenerate()
			self.oGS.NormalizeWeights()
			Result = self.oGS.Solve()
			self.memoData.append("Длина пути: {}".format(Result[0]))
			self.oGS.Visualize()
			self.canvas.draw()
			self.memoData.append("Маршрут: {}".format(Result[1]))
		except:
			self.canvas.figure.clear()
			self.memoData.clear()
			QMessageBox.critical(self, "Внимание!", "Обнаружена ошибка ввода. Попробуйте ещё раз.")
			return
	def ActCallHelp(self):
		self.frmHelp = TfrmHelp()
		
class TfrmHelp(QDialog):
	def __init__(self):
		super(TfrmHelp, self).__init__()
		self.setWindowTitle("Краткая справка")
		self.memoHelp = QTextEdit("Краткая справка по работе с программой. \n После авторизации необходимо ввести количество вершин в графе для задания условий задачи коммивояжёра. После этого необходимо нажать на кнопку '''Решить задачу коммивояжёра'''. \n При необходимости результат решения можно сохранить в файл путём нажатия кнопки '''Сохранить результат решения'''.")
		self.loHPrime = QHBoxLayout()
		self.loHPrime.addWidget(self.memoHelp)
		self.setLayout(self.loHPrime)
		self.show()
			
class TGUISubsystem:
	def __init__(self):
		self.Startup()
	def Startup(self):
		oApplication = QtGui.QApplication(sys.argv)
		self.frmAuthorization = TfrmAuthorization()
		self.frmAuthorization.show()
		sys.exit(oApplication.exec_())
	def Shutdown(self):
		oDS.Disconnect()
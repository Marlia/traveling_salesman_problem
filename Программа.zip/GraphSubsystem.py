﻿#GraphSubsystem.py
import matplotlib.pyplot as PLT
from matplotlib import rc
import numpy as NP
from numpy import sqrt

class TGraphSubsystem:
	def __init__(self, ATownCount, ATownStart, AFigure):
		self.fTownCount = ATownCount
		self.fTownStart = ATownStart
		self.fFigure = AFigure
		axisPlot = self.fFigure.add_subplot(111)
		axisPlot.clear()
		descFont = {'family': 'times new roman', 'weight': 'normal', 'size': 14}
		rc('font', **descFont)
		self.fWeights = NP.zeros([ATownCount, ATownCount])
	def NormalizeWeights(self):
		for decCounterA in NP.arange(0, self.fTownCount, 1):
			for decCounterB in NP.arange(0, self.fTownCount, 1):
				if decCounterA != decCounterB:
					self.fWeights[decCounterA, decCounterB] = sqrt((self.fX[decCounterA] - self.fX[decCounterB])**2 + (self.fY[decCounterA] - self.fY[decCounterB])**2)
				else:
					self.fWeights[decCounterA, decCounterB] = float('inf')
	def RandomGenerate(self):
		self.fX = NP.random.uniform(0, 100, self.fTownCount)
		self.fY = NP.random.uniform(0, 100, self.fTownCount)
	def Solve(self):
		self.fRoute = []
		self.fRoute.append(self.fTownStart)
		for decCounterA in NP.arange(1, self.fTownCount, 1):
			self.s = []
			for decCounterB in NP.arange(0, self.fTownCount, 1):
				self.s.append(self.fWeights[self.fRoute[decCounterA - 1], decCounterB])
			self.fRoute.append(self.s.index(min(self.s))) #Индекс ближайшего города.
			for decCounterB in NP.arange(0, decCounterA, 1):
				self.fWeights[self.fRoute[decCounterA], self.fRoute[decCounterB]] = float('inf')
				self.fWeights[self.fRoute[decCounterA], self.fRoute[decCounterB]] = float('inf')
		fltAmount = sum([sqrt((self.fX[self.fRoute[decCounterA]] - self.fX[self.fRoute[decCounterA + 1]])**2 + (self.fY[self.fRoute[decCounterA]] - self.fY[self.fRoute[decCounterA + 1]])**2) for decCounterA in NP.arange(0, self.fTownCount - 1, 1)]) + sqrt((self.fX[self.fRoute[self.fTownCount - 1]] - self.fX[self.fRoute[0]])**2 + (self.fY[self.fRoute[self.fTownCount - 1]] - self.fY[self.fRoute[0]])**2)
		return [fltAmount, self.fRoute]
	def Visualize(self):
		self.axisPlot = self.fFigure.add_subplot(111)
		self.axisPlot.clear()
		descFont = {'family': 'times new roman', 'weight': 'normal', 'size': 14}
		rc('font', **descFont)
		self.fX1=[self.fX[self.fRoute[decCounter]] for decCounter in NP.arange(0, self.fTownCount, 1)]
		self.fY1=[self.fY[self.fRoute[decCounter]] for decCounter in NP.arange(0, self.fTownCount, 1)]
		self.axisPlot.plot(self.fX1, self.fY1, color='r', linestyle=' ', marker='o')
		self.axisPlot.plot(self.fX1, self.fY1, color='b', linewidth = 1)   
		self.fX2=[self.fX[self.fRoute[self.fTownCount - 1]], self.fX[self.fRoute[0]]]
		self.fY2=[self.fY[self.fRoute[self.fTownCount - 1]], self.fY[self.fRoute[0]]]
		self.axisPlot.plot(self.fX2, self.fY2, color = 'g', linewidth = 2,  linestyle='-', label='Путь от последнего \n к начальному городу')
		for decCounter in range(self.fTownCount):
			self.axisPlot.text(self.fX[decCounter] + 0.2, self.fY[decCounter] + 0.2, str(decCounter))
		self.axisPlot.legend(loc='best')
		self.axisPlot.grid(True)
		return self.axisPlot